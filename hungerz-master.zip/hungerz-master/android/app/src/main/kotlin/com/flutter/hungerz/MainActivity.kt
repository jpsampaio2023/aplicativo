package com.flutter.hungerz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
