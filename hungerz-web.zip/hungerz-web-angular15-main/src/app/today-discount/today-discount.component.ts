import { Component } from '@angular/core';

@Component({
  selector: 'app-today-discount',
  templateUrl: './today-discount.component.html',
  styleUrls: ['./today-discount.component.scss']
})
export class TodayDiscountComponent {

}
