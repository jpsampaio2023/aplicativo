Map<String, String> german() => {
    "foodInsight": "Food-Einblick",
    "table": "Tisch",
    "today": "HEUTE",
    "week": "WOCHE",
    "month": "MONAT",
    "backToOrder": "Zurück zur Bestellung",
    "jan": "Jan",
    "totalOrders": "Gesamtbestellungen",
    "totalItems": "Gesamtanzahl",
    "timeCooked": "Zeit gekocht",
    "mostPopularItems": "BELIEBTESTE ARTIKEL",
    "kitchen": "KÜCHE",
    "pastOrders": "Vergangene Bestellungen",
    "noDataToShow": "Keine Daten zum Anzeigen",
    "enterMobileNumber": "Handynummer eingeben",
    "continuee": "Fortsetzen",
    "close": "Nah dran"
};
