Map<String, String> swahili() {
  return {
    'foodInsight': 'chakula Insight',
    'table': 'meza',
    'today': 'LEO',
    'week': 'WEEK',
    'month': 'mWEZI',
    'backToOrder': 'Back to Order',
    'jan': 'Jan',
    'totalOrders': 'jumla maagizo',
    'totalItems': 'vitu jumla',
    'timeCooked': 'wakati kupikwa',
    'mostPopularItems': 'Wengi Popular ITEMS',
    'kitchen': 'KITCHEN',
    'pastOrders': 'Maagizo zamani',
    'noDataToShow': 'Hakuna data ya kuonyesha',
    'enterMobileNumber': 'Weka Mkono Idadi',
    'continuee': 'kuendelea',
    'close': 'Close',
  };
}
