Map<String, String> romanian() => {
    "foodInsight": "Perspectivă alimentară",
    "table": "Masa",
    "today": "ASTĂZI",
    "week": "SĂPTĂMÂNĂ",
    "month": "LUNĂ",
    "backToOrder": "Înapoi la Comandă",
    "jan": "ian",
    "totalOrders": "totalul comenzilor",
    "totalItems": "articole totale",
    "timeCooked": "timp gătit",
    "mostPopularItems": "Cele mai populare articole",
    "kitchen": "BUCĂTĂRIE",
    "pastOrders": "Comenzi anterioare",
    "noDataToShow": "Nu există date de afișat",
    "enterMobileNumber": "Introduceți numărul de mobil",
    "continuee": "Continua",
    "close": "Închide"
};
