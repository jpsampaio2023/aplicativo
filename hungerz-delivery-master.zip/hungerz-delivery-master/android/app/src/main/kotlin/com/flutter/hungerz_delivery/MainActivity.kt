package com.flutter.hungerz_delivery

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
